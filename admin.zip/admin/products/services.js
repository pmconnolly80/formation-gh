(function () {
  'use strict';

  angular.module('products')
    .factory('productsFactory', productsFactory)
    .factory('confirmDeletion', confirmDeletion);


  confirmDeletion.$inject = ['$modal'];
  function confirmDeletion($modal) {

    return function(product) {
      console.log('Je vais effacer le produit', product);
      // $modal.open(...);
    };

  }

  /**
   * Service used to communicate with the backend.
   */
  productsFactory.$inject = ['$kinvey'];
  function productsFactory($kinvey) {
    return {
      getProducts: function() {
        return $kinvey.DataStore.find('products');
      },
      saveProduct: function(product) {
        return $kinvey.DataStore.save('products', product);
      },
      deleteProduct: function(productId) {
        return $kinvey.DataStore.destroy('products', productId);
      },
      getProduct: function(productId) {
        return $kinvey.DataStore.get('products', productId);
      }
    };
  }

  /**
   * Example of a data service that doesn't use Kinvey,
   * but sends manual HTTP requests to REST endpoints instead.
   */
  productsFactoryWithoutKinvey.$inject = ['$http'];
  function productsFactoryWithoutKinvey($http) {
    return {
      getProducts: function() {
        return $http.get('/api/products');
      },
      saveProduct: function(productData) {
        var id = productData._id;

        if (id == 0) {
          return $http.post('/api/products/add', productData);
        } else {
          return $http.post('/api/products/update', productData);
        }
      },
      deleteProduct: function(id) {
        return $http.get('/api/products/delete/' + id);
      },
      getProduct: function(id) {
        return $http.get('/api/products/details/' + id);
      }
    };
  }

})();
