(function () {
  'use strict';

  angular.module('products')
    .factory('productsFactory', productsFactory);

  /**
   * Service used to communicate with the backend.
   */
  productsFactory.$inject = ['$kinvey'];
  function productsFactory($kinvey) {
    return {
      getProducts: function() {
        return $kinvey.DataStore.find('products');
      },
      saveProduct: function(product) {
        return $kinvey.DataStore.save('products', product);
      },
      deleteProduct: function(productId) {
        return $kinvey.DataStore.destroy('products', productId);
      },
      getProduct: function(productId) {
        return $kinvey.DataStore.get('products', productId);
      }
    };
  }

})();
