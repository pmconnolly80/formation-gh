(function () {
  'use strict';

  angular.module('products')
    .controller('productListCtrl', productListCtrl)
    .controller('productEditCtrl', productEditCtrl);


  productListCtrl.$inject = ['confirmDeletion', 'productsReturn', 'productsFactory', 'flashMessageService'];
  function productListCtrl(confirmDeletion, productsReturn, productsFactory, flashMessageService) {
    var vm = this;
    vm.products = productsReturn;

    // Efface un produit.
    vm.deleteProduct = function(product) {

      confirmDeletion(product).then(deleteProductNow);

      // confirmDeletion(product).then(function(productRecuDeLaPromesse) {
      //   deleteProductNow(productRecuDeLaPromesse._id);
      // });
    };


    // Supprime le produit sur le serveur
    function deleteProductNow(productId) {
      productsFactory.deleteProduct(productId).then(function() {
        // S'il est supprimé du serveur, alors supprime-le du client
        var productToDeleteIndex = getIndexByKeyValue(vm.products, '_id', productId);
        vm.products.splice(productToDeleteIndex, 1);
        flashMessageService.setMessage('Produit effacé');
      });
    }

  }


  productEditCtrl.$inject = ['$stateParams', 'productsFactory', 'flashMessageService', '$state'];
  function productEditCtrl($stateParams, productsFactory, flashMessageService, $state) {
    var vm = this;
    var productId = $stateParams.productId;
    if (productId == 0) {
      // Nouveau produit
      vm.product = {};
    }
    else {
      // Produit existant
      productsFactory.getProduct(productId).then(function(data) {
        vm.product = data;
      });
    }

    vm.saveProduct = function(product) {
      productsFactory.saveProduct(product).then(function() {
        flashMessageService.setMessage('Produit enregistré');
        $state.go('productList');
      });
    }
  }


  /**
   * Renvoie l'indice de l'objet dans arr
   * dont la propriété key vaut value.
   */
  function getIndexByKeyValue(arr, key, value) {
    var indexFound = -1;
    angular.forEach(arr, function(obj, index) {
      if (obj[key] == value) {
        indexFound = index;
      }
    });
    return indexFound;
  }

})();
