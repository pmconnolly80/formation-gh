(function () {
  'use strict';

  angular.module('products')
    .controller('productListCtrl', productListCtrl)
    .controller('productEditCtrl', productEditCtrl);


  productListCtrl.$inject = ['productsReturn'];
  function productListCtrl(productsReturn) {
    var vm = this;
    vm.products = productsReturn;
  }


  function productEditCtrl() {
    var vm = this;
    // Votre code ici
  }

})();
