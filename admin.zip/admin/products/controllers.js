(function () {
  'use strict';

  angular.module('products')
    .controller('productListCtrl', productListCtrl)
    .controller('productEditCtrl', productEditCtrl);


  productListCtrl.$inject = ['productsFactory', 'flashMessageService', 'products', 'confirmDeletion'];
  function productListCtrl(productsFactory, flashMessageService, products, confirmDeletion) {
    // console.log('toto', toto);
    var vm = this;
    // Récupère les produits et publie-les sur le contrôleur
    // productsFactory.getProducts().then(function(data) {
    //   vm.products = data;
    // });
    vm.products = products;

    // Réalise l'effacement du produit
    function deleteProductNow() {

    }

    // Efface un produit
    vm.deleteProduct = function(product) {

      confirmDeletion(product).then(deleteProductNow);

      // productsFactory.deleteProduct(productId).then(function() {
      //   vm.products.splice(getProductFromId(vm.products, productId), 1);
      //   flashMessageService.setMessage('Produit supprimé !');
      // });
    };
  }


  productEditCtrl.$inject = ['productsFactory', '$stateParams', 'flashMessageService', '$state'];
  function productEditCtrl(productsFactory, $stateParams, flashMessageService, $state) {
    var vm = this;
    // A-t-on un productId ???
    var productId = $stateParams.productId;
    if (productId != 0) {
      // Produit existant. Va requêter Kinvey.
      vm.heading = 'Edition produit';
      productsFactory.getProduct(productId).then(function(data) {
        vm.product = data;
      });
    }
    else {
      // Nouveau produit
      vm.heading = 'Nouveau produit';
      vm.product = {};
    }

    // Sauvegarde le produit
    vm.saveProduct = function(product) {
      productsFactory.saveProduct(product).then(function() {
        flashMessageService.setMessage('Produit enregistré !');
        $state.go('productList');
      });
    }

  }

  function getProductFromId(products, id) {
    var idx = -1;
    angular.forEach(products, function(value, key){
      if (value._id == id) {
        idx = key;
      }
    });
    return idx;
  }

})();
