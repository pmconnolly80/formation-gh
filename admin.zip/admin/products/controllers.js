(function () {
  'use strict';

  angular.module('products')
    .controller('productListCtrl', productListCtrl)
    .controller('productEditCtrl', productEditCtrl);


  productListCtrl.$inject = ['productsFactory'];
  function productListCtrl(productsFactory) {
    var vm = this;
    // Récupère les produits et publie-les sur le contrôleur
    productsFactory.getProducts().then(function(data) {
      vm.products = data;
    }, function() {
      vm.products = [];
    });
  }


  productEditCtrl.$inject = ['productsFactory', '$stateParams', 'flashMessageService', '$state'];
  function productEditCtrl(productsFactory, $stateParams, flashMessageService, $state) {
    var vm = this;
    // A-t-on un productId ???
    var productId = $stateParams.productId;
    if (productId != 0) {
      // Produit existant. Va requêter Kinvey.
      vm.heading = 'Edition produit';
      productsFactory.getProduct(productId).then(function(data) {
        vm.product = data;
      });
    }
    else {
      // Nouveau produit
      vm.heading = 'Nouveau produit';
      vm.product = {};
    }

    // Sauvegarde le produit
    vm.saveProduct = function(product) {
      productsFactory.saveProduct(product).then(function() {
        flashMessageService.setMessage('Produit enregistré !');
        $state.go('productList');
      });
    }

  }

})();
