(function () {
  'use strict';

  angular.module('auth', [])

    .directive('currentUser', function() {
      return {
        templateUrl: 'common/currentUserView.html',
        controller: ['AuthService', function(AuthService) {
          this.getCurrentUser = function() {
            var user = AuthService.getCurrentUser();
            return (null !== user) ? user.username : '---';
          }
        }],
        controllerAs: 'cu'
      };
    });

})();
