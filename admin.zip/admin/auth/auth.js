(function () {
  'use strict';

  angular.module('auth', ['api_keys']);

})();
