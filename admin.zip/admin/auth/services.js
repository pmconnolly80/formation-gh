(function () {
  'use strict';

  angular.module('auth')

    .factory('AuthService', ['$kinvey', '$q', function($kinvey, $q) {

      return {
        login: login,
        register: register,
        logout: logout,
        getCurrentUser: getCurrentUser
      };

      function login(username, password) {
        var promise = $kinvey.User.login(username, password);
        return promise;
      }

      function register(username, password) {
        return $kinvey.User.signup({
          username : 'username',
          password : 'password'
        });
      }

      function logout() {
        var user = getCurrentUser();
        if (null !== user) {
          return $kinvey.User.logout();
        }
        else {
          return $q.when("Le user est déjà déconnecté");
        }
      }

      function getCurrentUser() {
        return $kinvey.getActiveUser();
      }
    }]);
})();
