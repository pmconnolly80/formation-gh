(function () {
  'use strict';

  angular.module('auth')
    .controller('LoginCtrl', LoginCtrl)
    .controller('RegisterCtrl', RegisterCtrl);

  //

  LoginCtrl.$inject = ['AuthService', '$state', 'flashMessageService'];
  function LoginCtrl(AuthService, $state, flashMessageService) {

    var vm = this;
    vm.errro = null;
    vm.credentials = {
      username: '',
      password: ''
    };
    vm.login = function(credentials) {
      AuthService
        .login(credentials.username, credentials.password)
        .then(function(){
            $state.go('home');
          },
          function() {
            flashMessageService.setMessage("Erreur authentification");
          }
        );

    };
  }

  function RegisterCtrl() {
    var vm = this;
    vm.credentials = {
      username: '',
      password: ''
    };
    vm.signup = function(credentials) {
      // A COMPLETER
    }
  }

})();
