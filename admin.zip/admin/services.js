(function () {
  'use strict';

  angular.module('myApp.services', [])

    .factory('kinveyService', kinveyService)
    .factory('AuthService', AuthService)
    .factory('productsFactory', productsFactory)
    .factory('myHttpInterceptor', myHttpInterceptor);

    /**
     * Initialize Kinvey for use in your app.
     */
    kinveyService.$inject = ['$kinvey', 'KINVEY_APP_KEY', 'KINVEY_APP_SECRET'];
    function kinveyService($kinvey, KINVEY_APP_KEY, KINVEY_APP_SECRET) {
      return {
        init: function() {
          return $kinvey.init({
            appKey    : KINVEY_APP_KEY,
            appSecret : KINVEY_APP_SECRET
          });
        }
      }
    }

    /**
     * Authentication service.
     * Deals with registering new users, logging users in and out.
     */
    AuthService.$inject = ['$kinvey', '$q'];
    function AuthService($kinvey, $q) {
      // Each method must return a promise!
      return {
        login: login,
        logout: logout,
        signup: signup
      };

      function login(credentials) {
        var promise = $kinvey.User.login(credentials);
        return promise;
      }

      function logout() {
        var user = $kinvey.getActiveUser();  // synchronous
        if (null !== user) {
          var promise = $kinvey.User.logout();
        }
        else {
          var promise = $q.when('User already logged out');  // always return a promise
        }
        return promise;
      }

      function signup(credentials) {
        // NB. The created user is automatically logged in and stored as the active user.
        var promise = $kinvey.User.signup(credentials);
        return promise;
      }
    }

    /**
     * Example of an authentication service that doesn't use Kinvey,
     * but sends manual HTTP requests to authentification endpoints instead.
     */
    AuthServiceWithoutKinvey.$inject = ['$http']
    function AuthServiceWithoutKinvey($http) {
      return {
        login: login,
        logout: logout,
        signup: signup
      };
      function login(credentials) {
        return $http.post('/api/login', credentials);
      }
      function logout() {
        return $http.get('/api/logout');
      }
      function signup(credentials) {
        return $http.post('/api/signup', credentials);
      }
    }

    /**
     * Service used to communicate with the backend.
     */
    productsFactory.$inject = ['$kinvey'];
    function productsFactory($kinvey) {
      return {
        getProducts: function() {
          return $kinvey.DataStore.find('products');
        },
        saveProduct: function(product) {
          return $kinvey.DataStore.save('products', product);
        },
        deleteProduct: function(productId) {
          return $kinvey.DataStore.destroy('products', productId);
        },
        getProduct: function(productId) {
          return $kinvey.DataStore.get('products', productId);
        }
      };
    };

    /**
     * Example of a data service that doesn't use Kinvey,
     * but sends manual HTTP requests to REST endpoints instead.
     */
    productsFactoryWithoutKinvey.$inject = ['$http'];
    function productsFactoryWithoutKinvey($http) {
      return {
        getProducts: function() {
          return $http.get('/api/products');
        },
        saveProduct: function(productData) {
          var id = productData._id;

          if (id == 0) {
            return $http.post('/api/products/add', productData);
          } else {
            return $http.post('/api/products/update', productData);
          }
        },
        deleteProduct: function(id) {
          return $http.get('/api/products/delete/' + id);
        },
        getProduct: function(id) {
          return $http.get('/api/products/details/' + id);
        }
      };
    };

    myHttpInterceptor.$inject = ['$q', '$location'];
    function myHttpInterceptor($q, $location) {
      return {
        responseError: function(response) {
          if (response.status === 401) {
            $location.path('/login');
            return $q.reject(response);
          }
          return $q.reject(response);
        }
      };
    }

})();
