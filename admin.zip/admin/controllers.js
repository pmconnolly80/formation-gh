(function () {
  'use strict';

  angular.module('myApp.controllers', [])

    .controller('AppCtrl', AppCtrl)
    .controller('AdminProductsCtrl', AdminProductsCtrl)
    .controller('AddEditProductCtrl', AddEditProductCtrl)
    .controller('AdminLoginCtrl', AdminLoginCtrl)
    .controller('AdminSignupCtrl', AdminSignupCtrl);


  AppCtrl.$inject = ['AuthService', 'flashMessageService', '$location'];
  function AppCtrl(AuthService, flashMessageService, $location) {
    var vm = this;
    vm.logout = function() {
      console.log('vm.logout');
      AuthService.logout().then(function() {
        console.log('user logged out');
        $location.path('/login');
        flashMessageService.setMessage('Vous avez été déconnecté.');
      },
      function(err) {
        console.log("could not log out", err);
        flashMessageService.setMessage('Impossible de vous déconnecter.');
      });
    };
  }

  AdminProductsCtrl.$inject = ['productsFactory', 'flashMessageService', '$location', '$log'];
    function AdminProductsCtrl(productsFactory, flashMessageService, $location, $log) {
      var vm = this;

      productsFactory.getProducts().then(
        function(response) {
          vm.products = response;
        },
        function(err) {
          $log.error(err);
        });

      vm.deleteProduct = function(productId) {
        productsFactory.deleteProduct(productId).then(
          function() {
            flashMessageService.setMessage('Produit supprimé avec succès');
            $location.path('/products');
          },
          function(err) {
            $log.error('Erreur lors de la suppression');
          }
        );
      };
    }


    AddEditProductCtrl.$inject = ['productsFactory', 'flashMessageService', '$stateParams', '$location', '$log'];
    function AddEditProductCtrl(productsFactory, flashMessageService, $stateParams, $location, $log) {
      var vm = this;
      vm.product = {};

      vm.heading = 'Ajouter un nouveau produit';
      if ($stateParams.productId != 0) {
        vm.heading = 'Mettre à jour le produit';
        productsFactory.getProduct($stateParams.productId).then(
          function(response) {
            vm.product = response;
            $log.info(vm.product);
          },
          function(err) {
            $log.error(err);
          });
      }

      vm.saveProduct = function(product) {
        productsFactory.saveProduct(product).then(
          function() {
            flashMessageService.setMessage('Produit enregistré avec succès');
            $location.path('/products');
          },
          function(err) {
            $log.error('Erreur lors de la sauvegarde');
          }
        );
      };

      vm.updateURL = function() {
        // vm.product.url = $filter('formatURL')(vm.product.title);
      };
    }


    AdminLoginCtrl.$inject = ['AuthService', 'flashMessageService'];
    function AdminLoginCtrl(AuthService, flashMessageService) {
      var vm = this;
      vm.credentials = {
        username: '',
        password: ''
      };
      vm.login = function(credentials) {
        AuthService.login(credentials).then(
          function(res) {
            // $cookies.loggedInUser = res.data;
            // $location.path('/admin/product');
            console.log(res);
          },
          function(err) {
            // console.error('AdminLoginCtrl ERROR', err);
            // $log.log(err);
            flashMessageService.setMessage(err.data);
          });
      };
    }


    AdminSignupCtrl.$inject = ['AuthService', 'flashMessageService'];
    function AdminSignupCtrl(AuthService, flashMessageService) {
      var vm = this;
      vm.credentials = {
        username: '',
        password: ''
      };
      vm.signup = function(credentials) {
        AuthService.signup(credentials).then(
          function(res) {
            // $cookies.loggedInUser = res.data;
            // $location.path('/admin/product');
            console.log('Signup success', res);
          },
          function(err) {
            console.error('Signup ERROR', err);
            // $log.log(err);
            flashMessageService.setMessage(err.data);
          });
      }
    }

})();
