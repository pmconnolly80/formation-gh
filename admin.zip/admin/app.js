(function () {
  'use strict';
  angular.module('myApp',
        ['auth', 'ui.router', 'kinvey', 'message.flash', 'products'])

    .run(['KinveyService', function(KinveyService) {

    }])
    .config(configRoutes)
    .factory('KinveyService', KinveyService)
    .controller('AppCtrl', AppCtrl)
    .constant('AUTH_EVENTS', {
      unauthorizedAccess: 'User is not authorized'
    })

    .directive('adminMenu', function() {
      return {
        templateUrl: 'common/adminMenu.html'
      };
    })

    ;

    //

    configRoutes.$inject = ['$stateProvider', '$urlRouterProvider'];
    function configRoutes($stateProvider, $urlRouterProvider) {
      // Declare states here with $stateProvider.state().
      $stateProvider
        .state('admin', {
          abstract: true,
          template: '<ui-view></ui-view>',
          resolve: {
            kinveyIsReady: ['KinveyService', function(KinveyService) {
              return KinveyService.kinveyIsReady;
            }]
          }
        })
        .state('login', {
          parent: 'admin',
          url: '/login',
          templateUrl: 'auth/loginView.html',
          controller: 'LoginCtrl as vm'
        })
        .state('register', {
          parent: 'admin',
          url: '/register',
          templateUrl: 'auth/registerView.html',
          controller: 'RegisterCtrl as vm'
        })
        .state('home', {
          parent: 'admin',
          url: '/home',
          templateUrl: 'common/homeView.html',
          data: {
            authLevel: 'login'
          }
        })
        /**
         * Products
         */
        .state('productList', {
          parent: 'admin',
          url: '/products',
          templateUrl: 'products/productListView.html',
          controller: 'productListCtrl as vm',
          resolve: {
            productsReturn: ['productsFactory', 'kinveyIsReady', function(productsFactory, kinveyIsReady) {
              return productsFactory.getProducts();
            }]
          }
        })
        .state('productEdit', {
          parent: 'admin',
          url: '/product/:productId',
          templateUrl: 'products/productEditView.html',
          controller: 'productEditCtrl as vm'
        })
        ;
      $urlRouterProvider.otherwise('/login');
    }

    KinveyService.$inject = ['$kinvey', '$rootScope', 'AuthService', 'KINVEY_APP_KEY', 'KINVEY_APP_SECRET'];
    function KinveyService($kinvey, $rootScope, AuthService, KINVEY_APP_KEY, KINVEY_APP_SECRET) {
      // Initialise Kinvey.
      var promise = $kinvey.init({
        appKey    : KINVEY_APP_KEY,
        appSecret : KINVEY_APP_SECRET
      });
      promise.then(function() {
        $rootScope.$on('$stateChangeStart', function(event, toState) {
          var user = AuthService.getCurrentUser();
          if (toState.name == 'login' || toState.name == 'register') {
            return;
          }
          if (user === null) {
            event.preventDefault();
          }
        });
      })
      return {
        kinveyIsReady: promise
      }
    }

    AppCtrl.$inject = ['KinveyService', 'AuthService', '$state', 'flashMessageService'];
    function AppCtrl(KinveyService, AuthService, $state, flashMessageService) {
      var vm = this;

      vm.logout = function() {
        AuthService.logout()
          .then(function() {
            flashMessageService.setMessage("Vous êtes déconnecté");
            $state.go('login');
          });
      }
    }

})();
