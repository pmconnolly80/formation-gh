(function () {
  'use strict';

  angular.module('myApp', [
    'kinvey',
    'auth',
    'ui.router',
    'api_keys',
    'message.flash',
    'products',
    'ui.bootstrap'
    ])

    .config(configRoutes)

    .run(['KinveyService', function(KinveyService) {
      KinveyService.init().then(function() {
        // Kinvey est initialisé
      });
    }])

    .controller('AppCtrl', AppCtrl)

    .directive('adminMenu', function() {
      return {
        templateUrl: 'common/adminMenuView.html'
      };
    });

    //

    configRoutes.$inject = ['$stateProvider', '$urlRouterProvider'];
    function configRoutes($stateProvider, $urlRouterProvider) {

      // Declare states here with $stateProvider.state().
      $stateProvider

        /**
         * Etat abstrait dont la seule raison d'être
         * est de contenir une dépendance à l'initialisation de Kinvey.
         */
        .state('admin', {
          abstract: true,
          resolve: {
            kinveyIsInitialized: ['KinveyService', function(KinveyService) {
              return KinveyService.init();
            }]
          },
          template: '<ui-view></ui-view>'
        })

        .state('login', {
          parent: 'admin',
          url: '/login',
          templateUrl: 'auth/loginView.html',
          controller: 'LoginCtrl',
          controllerAs: 'vm'
        })
        .state('register', {
          parent: 'admin',
          url: '/register',
          templateUrl: 'auth/registerView.html',
          controller: 'RegisterCtrl',
          controllerAs: 'vm'
        })
        .state('home', {
          parent: 'admin',
          url: '/home',
          templateUrl: 'common/homeView.html',
          controller: ['AuthService', '$state', function(AuthService, $state) {
            var currentUser = AuthService.getCurrentUser();
            if (null === currentUser) {
              return $state.go('login');
            }
          }]
        })

        //
        // Routes "Produits"
        //
        .state('productList', {
          parent: 'admin',
          url: '/products',
          templateUrl: 'products/productListView.html',
          controller: 'productListCtrl',
          controllerAs: 'vm',
          resolve: {
            products: ['$q', 'productsFactory', 'kinveyIsInitialized',
                function($q, productsFactory, kinveyIsInitialized) {
              // return $q.when("je suis le contenu de toto");
              return productsFactory.getProducts();
            }]
          }
        })
        .state('productEdit', {
          parent: 'admin',
          url: '/product/:productId/edit',
          templateUrl: 'products/productEditView.html',
          controller: 'productEditCtrl',
          controllerAs: 'vm'
        })
        .state('orderList', {
          parent: 'admin',
          url: '/orders',
          templateUrl: 'common/orderListView.html'
        })
        ;

      $urlRouterProvider.otherwise('/home');
    }

    AppCtrl.$inject = ['AuthService', '$timeout', 'KinveyService', '$location', 'flashMessageService'];
    function AppCtrl(AuthService, $timeout, KinveyService, $location, flashMessageService) {
      var vm = this;

      KinveyService.init().then(function() {
        vm.currentUser = AuthService.getCurrentUser();
      })

      vm.envoieMessage = function() {
        flashMessageService.setMessage('Y a un problème');
      }

      vm.logout = function() {
        AuthService.logout().then(function() {
          // Succès.... Ne marche pas...
        }, function() {
          console.log('cb error');
          // $state.go('login');
          $location.path('/login');
        });
      }
    }


})();
