(function () {
  'use strict';

  angular.module('myApp',
        ['auth', 'ui.router', 'kinvey'])

    .config(configRoutes)
    .controller('AppCtrl', AppCtrl)
    .factory('KinveyService', KinveyService);

    //

    KinveyService.$inject = ['$kinvey', 'KINVEY_APP_KEY', 'KINVEY_APP_SECRET'];
    function KinveyService($kinvey, KINVEY_APP_KEY, KINVEY_APP_SECRET) {
      // Initialise Kinvey.
      var promise = $kinvey.init({
        appKey    : KINVEY_APP_KEY,
        appSecret : KINVEY_APP_SECRET
      });
      return {
        kinveyIsReady: promise
      }
    }

    configRoutes.$inject = ['$stateProvider', '$urlRouterProvider'];
    function configRoutes($stateProvider, $urlRouterProvider) {
      // Declare states here with $stateProvider.state().
      $stateProvider
        .state('login', {
          url: '/login',
          templateUrl: 'auth/loginView.html',
          controller: 'LoginCtrl as vm'
        })
        .state('register', {
          url: '/register',
          templateUrl: 'auth/registerView.html',
          controller: 'RegisterCtrl as vm'
        })
        .state('home', {
          url: '/home',
          templateUrl: 'common/homeView.html'
        })
        ;
      $urlRouterProvider.otherwise('/home');
    }

    AppCtrl.$inject = ['KinveyService', 'AuthService', '$state'];
    function AppCtrl(KinveyService, AuthService, $state) {
      var vm = this;

      var promise = KinveyService.kinveyIsReady;
      promise.then(function(data) {
        vm.currentUser = AuthService.getCurrentUser();
      });

      vm.logout = function() {
        AuthService.logout();
        $state.go('login');
      }

    }

})();
