(function () {
  'use strict';

  angular.module('myApp', [
    'kinvey',
    'ui.router',
    'myApp.controllers',
    'myApp.services',
    'myApp.directives',
    'message.flash',
    'api_keys'
    ])

    .config(configHttp)
    .config(configRoutes)
    // .run(['kinveyService', function(kinveyService) {
    //   kinveyService.init();
    // }])
    ;

    configRoutes.$inject = ['$stateProvider', '$urlRouterProvider'];
    function configRoutes($stateProvider, $urlRouterProvider) {
      $stateProvider
        // Abstract root state providing a resolved dependency to all child states.
        .state('root', {
          abstract: true,
          resolve: {
            kinvey: ['kinveyService', function(kinveyService) {
              console.log('resolve.kinvey');
              return kinveyService.init();
            }]
          },
          template: '<ui-view/>'
        })

        // States for authentication.
        .state('login', {
          url: '/login',
          templateUrl: 'partials/admin/login.html',
          controller: 'AdminLoginCtrl as ctrl'
        })
        .state('signup', {
          url: '/signup',
          templateUrl: 'partials/admin/signup.html',
          controller: 'AdminSignupCtrl as ctrl'
        })

        // States for products.
        .state('root.productList', {
          url: '/products',
          templateUrl: 'partials/admin/products.html',
          controller: 'AdminProductsCtrl as ctrl'
          // resolve: {
          //   products: ['productsFactory', function () {
          //     return productsFactory.getProducts();
          //   }]
          // }
        })
        .state('root.productEdit', {
          url: '/add-edit-product/:productId',
          templateUrl: 'partials/admin/add-edit-product.html',
          controller: 'AddEditProductCtrl as ctrl'
          // resolve: {
          //   product: ['$stateParams', function ($stateParams) {
          //     var productId = $stateParams.productId;
          //     return productsFactory.getProduct(productId);
          //   }]
          // }
        })
        .state('root.orderList', {
          url: '/orders',
          templateUrl: 'partials/admin/orders.html'
        })

        // Other states.
        .state('root.home', {
          url: '/home',
          templateUrl: 'partials/admin/home.html'
        });

      // Default state.
      $urlRouterProvider.otherwise('/home');
    }

    configHttp.$inject = ['$httpProvider'];
    function configHttp($httpProvider) {
      $httpProvider.interceptors.push('myHttpInterceptor');
    }

})();
