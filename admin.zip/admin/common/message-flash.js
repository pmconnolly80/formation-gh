(function () {
  'use strict';

  angular.module('message.flash', [])

    .factory('flashMessageService', ['$rootScope', function($rootScope) {
      var msg = '';
      return {
        setMessage: function(message) {
          msg = message;
          $rootScope.$broadcast('NEW_MESSAGE');
        },
        getMessage: function() {
          return msg;
        }
      };
    }])

    .directive('messageFlash', function() {
      return {
        template: '<div class="alert alert-info" ng-show="isVisible">{{message}}</div>',
        controller: ['$scope', 'flashMessageService', '$timeout',
                 function ($scope, flashMessageService, $timeout) {
          $scope.isVisible = false;
          $scope.$on('NEW_MESSAGE', function() {
            $scope.isVisible = true;
            $scope.message = flashMessageService.getMessage();
            $timeout(function() {
              $scope.isVisible = false;
            }, 3000);
          });
        }]
      };
    });

})();
