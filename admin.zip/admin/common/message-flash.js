(function () {
  'use strict';

  angular.module('message.flash', [])
    .factory('flashMessageService', flashMessageService)
    .directive('messageFlash', messageFlash);


  flashMessageService.$inject = ['$rootScope'];
  function flashMessageService($rootScope) {
    var message = '';
    return {
      setMessage: function(currentMessage) {
        message = currentMessage;
        // Émet un événement
        $rootScope.$broadcast('NEW_MESSAGE');
      },
      getMessage: function() {
        var returnedMessage = message;
        message = '';
        return returnedMessage;
      }
    };
  }

  function messageFlash() {
    return {
      template: '<div class="alert alert-info"ng-show="message">{{message}}</div>',
      controller: ['$scope', '$timeout', 'flashMessageService',
                function($scope, $timeout, flashMessageService) {

        // Quand un nouveau message est setté....
        $scope.$on('NEW_MESSAGE', function() {
          // Assigne-le au scope de la directive
          $scope.message = flashMessageService.getMessage();
          // Au bout de 2 secondes, fais disparaître le message
          $timeout(function() {
            $scope.message = '';
          }, 2000);
        });

      }]
    };
  }

})();
