(function () {
  'use strict';

  angular.module('myApp.directives', [])

    .directive('adminLogin', function() {
      return {
        controller: ['$scope', '$kinvey', '$timeout', function($scope, $kinvey, $timeout) {
          $timeout(function() {
            // With Kinvey: `user` will be null if current user is not authenticated
            var user = $kinvey.getActiveUser();
            if (null !== user) {
              $scope.activeUser = user.username;
            }
          }, 1500);
          // With custom cookie-based authentication:
          // NB. The `$cookies` service must be injected in the controller function!
          // var user = $cookies.loggedInUser;
        }],
        templateUrl: 'partials/admin/current-user.html'
      };
    })
})();
