(function () {
  'use strict';

  angular.module('myApp', [
    'kinvey',
    'ngRoute',
    'myApp.controllers',
    'myApp.services',
    'myApp.directives',
    'message.flash',
    'api_keys'
    ])

    .config(configRoutes)
    .config(configHttp)
    .run(['kinveyService', function(kinveyService) {
      kinveyService.init();
    }]);

    configRoutes.$inject = ['$routeProvider'];
    function configRoutes($routeProvider) {
      $routeProvider
        .when('/login', {
          templateUrl: 'partials/admin/login.html',
          controller: 'AdminLoginCtrl',
          controllerAs: 'ctrl'
        })
        .when('/signup', {
          templateUrl: 'partials/admin/signup.html',
          controller: 'AdminSignupCtrl',
          controllerAs: 'ctrl'
        })
        .when('/home', {
          templateUrl: 'partials/admin/home.html'
        })
        .when('/products', {
          templateUrl: 'partials/admin/products.html',
          controller: 'AdminProductsCtrl',
          controllerAs: 'ctrl'
        })
        .when('/add-edit-product/:productId', {
          templateUrl: 'partials/admin/add-edit-product.html',
          controller: 'AddEditProductCtrl',
          controllerAs: 'ctrl'
        })
        .when('/orders', {
          templateUrl: 'partials/admin/orders.html'
        })
        // No redirection on "otherwise".
        // Redirection will be done after Kinvey has initialized.
        .otherwise({
          templateUrl: 'partials/admin/loading.html'
        });
    }

    configHttp.$inject = ['$httpProvider'];
    function configHttp($httpProvider) {
      $httpProvider.interceptors.push('myHttpInterceptor');
    }

})();
