/**
 * @file
 * Main app
 */
(function () {
  'use strict';
  angular.module('dvdStore', ['kinvey.helper', 'cart', 'ngRoute'])

    .config(['$routeProvider', function($routeProvider) {

      $routeProvider
        .when('/products', {
          templateUrl: 'views/productList.html'
        })
        .when('/checkout', {
          templateUrl: 'views/checkoutSummary.html'
        })
        .otherwise({
          redirectTo: '/products'
        });


    }]);
})();
