/**
 * @file
 * Main app
 */
(function () {
  'use strict';
  angular.module('dvdStore', ['customFilters', 'kinvey.helper']);
})();
