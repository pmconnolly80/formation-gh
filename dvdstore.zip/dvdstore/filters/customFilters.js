(function () {
  'use strict';

  angular.module('dvdStore')

    .filter('unique', function() {
      return function(products, propertyName) {
        if (angular.isArray(products)) {
          var items = [];
          angular.forEach(products, function(product) {
            if (angular.isDefined(product[propertyName])) {
              angular.forEach(product[propertyName], function(item) {
                if (items.indexOf(item) === -1) {
                  items.push(item);
                }
              });
            }
          });
          items.sort();
          return items;
        }
        else {
          return products;
        }
      };
    });


})();
