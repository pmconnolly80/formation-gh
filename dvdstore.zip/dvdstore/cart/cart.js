(function () {
  'use strict';

  angular.module('cart', [])

    .factory('CartService', function() {

      var cartData = [];

      return {

        addProduct: function(id, name, price) {
          var indexProduct = getIndexByKeyValue(cartData, 'id', id);

          if (indexProduct === - 1) {
            // Nouveau produit - Ajoute au panier avec quantité 1
            cartData.push({
              id: id,
              name: name,
              price: price,
              qty: 1
            });
          }
          else {
            // Produit déjà dans panier - Incrémente quantité
            cartData[indexProduct].qty++;
          }
        },

        removeProduct: function(id) {
          var indexProduct = getIndexByKeyValue(cartData, 'id', id);
          if (indexProduct !== - 1) {
            cartData.splice(indexProduct, 1);
          }
        },

        getProducts: function() {
          return cartData;
        },

        clearCart: function() {
          cartData = [];
        }
      };

      /**
       * Renvoie l'indice de l'objet dans arr
       * dont la propriété key vaut value.
       */
      function getIndexByKeyValue(arr, key, value) {
        var indexFound = -1;
        angular.forEach(arr, function(obj, index) {
          if (obj[key] == value) {
            indexFound = index;
          }
        });
        return indexFound;
      }

    })

    .directive('cartSummary', function() {
      return {
        restrict: 'E',
        templateUrl: 'cart/cartSummary.html',
        controller: ['CartService', function(CartService) {
          this.getNumArticles = function() {
            var numArticles = 0;
            var cartData = CartService.getProducts();
            angular.forEach(cartData, function(cartItem) {
              numArticles += cartItem.qty;
            });
            return numArticles;
          };
          this.getTotal = function() {
            var total = 0;
            var cartData = CartService.getProducts();
            angular.forEach(cartData, function(cartItem) {
              total += cartItem.qty * cartItem.price;
            });
            return total;
          };
        }],
        controllerAs: 'cartCtrl'
      };
    });

})();
