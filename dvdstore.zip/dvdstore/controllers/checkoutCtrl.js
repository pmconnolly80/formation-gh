(function () {
  'use strict';

  angular.module('dvdStore')
    .controller('checkoutCtrl', checkoutCtrl);

  function checkoutCtrl() {
  }

})();
