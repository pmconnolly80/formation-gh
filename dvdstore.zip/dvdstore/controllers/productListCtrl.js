(function () {
  'use strict';

  angular.module('dvdStore')

    .controller('productListCtrl', function(CartService) {

      var selectedCategory;

      this.selectCategory = function(category) {
        selectedCategory = category;
      };

      this.getButtonClass = function(category) {
        if (category == selectedCategory) {
          return 'btn-primary';
        }
      };

      this.FilterProductFn = function(product) {
        return (selectedCategory == null
              || product.categories.indexOf(selectedCategory) !== -1);
      }

      this.addToCart = function(product) {
        CartService.addProduct(product._id, product.name, product.price);
      }

    });

})();
