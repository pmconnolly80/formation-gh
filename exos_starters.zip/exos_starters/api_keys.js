/**
 * Tiny AngularJS app whose sole purpose is to store API Keys.
 */
(function () {
  'use strict';

    angular.module('api_keys', [])
      .constant('KINVEY_APP_KEY', '__YOUR_APP_KEY__')
      .constant('KINVEY_APP_SECRET', '__YOUR_APP_SECRET__');

})();
