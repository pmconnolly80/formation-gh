(function () {
  'use strict';

  angular.module('products')
    .factory('productsFactory', productsFactory);

  /**
   * Service used to communicate with the backend.
   */
  function productsFactory() {
  }

})();
