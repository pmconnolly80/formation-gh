(function () {
  'use strict';

  angular.module('products')
    .controller('productListCtrl', productListCtrl)
    .controller('productEditCtrl', productEditCtrl);


  function productListCtrl() {
    var vm = this;
    // Votre code ici
  }


  function productEditCtrl() {
    var vm = this;
    // Votre code ici
  }

})();
