(function () {
  'use strict';

  angular.module('auth')
    .controller('LoginCtrl', LoginCtrl)
    .controller('RegisterCtrl', RegisterCtrl);

  //

  function LoginCtrl() {
    var vm = this;
    vm.credentials = {
      username: '',
      password: ''
    };
    vm.login = function(credentials) {
      // A COMPLETER
    };
  }

  function RegisterCtrl() {
    var vm = this;
    vm.credentials = {
      username: '',
      password: ''
    };
    vm.signup = function(credentials) {
      // A COMPLETER
    }
  }

})();
