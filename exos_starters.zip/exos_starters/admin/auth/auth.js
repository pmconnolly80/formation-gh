(function () {
  'use strict';
  angular.module('auth', []);
})();
