(function () {
  'use strict';

  angular.module('message.flash', []);

})();
