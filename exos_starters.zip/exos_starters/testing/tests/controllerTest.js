describe("Controller Test", function() {

  // Arrange
  var mockScope, controller, mockInterval, mockTimeout;

  beforeEach(angular.mock.module("myApp"));

  beforeEach(angular.mock.inject(function($controller, $rootScope,
    $http, $interval, $timeout, $log) {
    mockScope = $rootScope.$new();
    mockInterval = $interval;
    mockTimeout = $timeout;
    $controller("defaultCtrl", {
      $scope: mockScope,
      $http: $http,
      $interval: mockInterval,
      $timeout: mockTimeout
    });
  }));

  // Act and Assess
  it("Creates variable", function() {
    expect(mockScope.counter).toEqual(0);
  })

  it("Increments counter", function() {

    // --- COMPLETER ICI ---

  });

});
