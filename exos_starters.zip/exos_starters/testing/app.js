(function () {
  'use strict';
  angular.module('myApp', [])

    .controller('defaultCtrl', function ($scope, $http, $interval, $timeout) {

        $scope.intervalCounter = 0;
        $scope.timerCounter = 0;

        $interval(function () {
          $scope.intervalCounter++;
        }, 5, 10);

        $timeout(function () {
          $scope.timerCounter++;
        }, 5);

        $scope.counter = 0;

        $scope.incrementCounter = function () {
          $scope.counter++;
        }
    });

})();
